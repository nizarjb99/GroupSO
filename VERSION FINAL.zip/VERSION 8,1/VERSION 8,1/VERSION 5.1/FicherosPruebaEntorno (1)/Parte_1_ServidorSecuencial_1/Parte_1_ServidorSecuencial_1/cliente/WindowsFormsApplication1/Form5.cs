﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form5 : Form
    {
        private Socket server;

        public Form5 (Socket serverConnection)
        {
            InitializeComponent ();
            server = serverConnection;
        }

        public void SetData(DataTable data)
        {
            dataGridViewBloqueados.DataSource = data;
        }

        private void dataGridViewBloqueados_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void desbloquearBtn_Click(object sender, EventArgs e)
        {
            if (dataGridViewBloqueados.SelectedRows.Count > 0)
            {
                string usuarioSeleccionado = dataGridViewBloqueados.SelectedRows[0].Cells["Nombre_Usuario"].Value.ToString();
                string mensaje = $"37/UNBLOCK/{usuarioSeleccionado}";
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);

                try
                {
                    server.Send(msg);

                    // Eliminar del DataGridView tras desbloquear
                    dataGridViewBloqueados.Rows.RemoveAt(dataGridViewBloqueados.SelectedRows[0].Index);

                    MessageBox.Show($"Has desbloqueado a {usuarioSeleccionado}.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al desbloquear: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Selecciona un usuario para desbloquear.");
            }
        }
    }
}
