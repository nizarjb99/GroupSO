﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form6 : Form
    {
        private Label diceResultLabel;
        private Label currentPlayerLabel;
        private PictureBox[][] playerPieces;
        private int currentPlayer;
        private int diceResult;
        private Random random;
        private Point[] boardPositions;
        private Socket clientSocket;
        private bool isMyTurn;
        private int playerID;

        public Form6(Socket clientSocket, int playerID, string[] initialBoardState, int currentTurn)
        {
            InitializeComponent();
            InitializeCustomComponents();

            this.clientSocket = clientSocket;
            this.playerID = playerID;
            this.isMyTurn = false;

            InitializeBoardState(initialBoardState, currentTurn);
            StartListeningToServer();
        }
        private void InitializeCustomComponents()
        {
            // Inicializar las posiciones del tablero (ajusta según tu diseño)
            InitializeBoardPositions();

            // Inicializar las fichas
            playerPieces = new PictureBox[4][]; // 4 jugadores
            for (int i = 0; i < 4; i++) // Jugadores
            {
                playerPieces[i] = new PictureBox[4]; // Cada jugador tiene 4 fichas
                for (int j = 0; j < 4; j++) // Fichas por jugador
                {
                    playerPieces[i][j] = new PictureBox
                    {
                        Size = new Size(30, 30), // Tamaño de la ficha
                        BackColor = GetPlayerColor(i), // Color de las fichas según el jugador
                        Location = GetInitialPosition(i, j), // Posición inicial específica para cada ficha
                        BorderStyle = BorderStyle.FixedSingle
                    };
                    boardPictureBox.Controls.Add(playerPieces[i][j]); // Agregar al tablero
                }
            }
            // Etiqueta para mostrar el resultado del dado
            diceResultLabel = new Label
            {
                Text = "Dado: 0",
                Location = new Point(650, 160),
                AutoSize = true,
                Font = new Font("Arial", 12, FontStyle.Bold)
            };
            this.Controls.Add(diceResultLabel);

            // Etiqueta para mostrar el turno actual
            currentPlayerLabel = new Label
            {
                Text = "Turno: Jugador 1",
                Location = new Point(650, 200),
                AutoSize = true,
                Font = new Font("Arial", 12, FontStyle.Bold)
            };
            this.Controls.Add(currentPlayerLabel);

            // Inicializar variables
            random = new Random();
            currentPlayer = 1;

            // Inicializar posiciones del tablero
            InitializeBoardPositions();

            // Inicializar fichas de jugadores
            InitializePlayerPieces();
        }

        private void InitializeBoardPositions()
        {
            boardPositions = new Point[52]; // Ajusta según el diseño del tablero

            // Ejemplo: Casillas distribuidas en un rectángulo (personaliza para tu diseño)
            int x = 100, y = 100;
            for (int i = 0; i < 52; i++)
            {
                boardPositions[i] = new Point(x, y);
                if (i < 13) x += 40;           // Línea superior
                else if (i < 26) y += 40;      // Línea derecha
                else if (i < 39) x -= 40;      // Línea inferior
                else y -= 40;                  // Línea izquierda
            }
        }

        private void InitializePlayerPieces()
        {
            playerPieces = new PictureBox[4][];
            for (int i = 0; i < 4; i++)
            {
                playerPieces[i] = new PictureBox[4];
                for (int j = 0; j < 4; j++)
                {
                    playerPieces[i][j] = new PictureBox
                    {
                        Size = new Size(30, 30),
                        BackColor = GetPlayerColor(i),
                        Location = boardPositions[0], // Todas las fichas comienzan fuera del tablero
                        BorderStyle = BorderStyle.FixedSingle
                    };
                    boardPictureBox.Controls.Add(playerPieces[i][j]);
                }
            }
        }
        private Point GetInitialPosition(int playerIndex, int pieceIndex)
        {
            // Coordenadas iniciales para cada jugador (ajusta según el diseño del tablero)
            Point[][] initialPositions = {
        new[] { new Point(50, 50), new Point(80, 50), new Point(50, 80), new Point(80, 80) },       // Jugador 1 (rojo)
        new[] { new Point(500, 50), new Point(530, 50), new Point(500, 80), new Point(530, 80) },   // Jugador 2 (azul)
        new[] { new Point(500, 500), new Point(530, 500), new Point(500, 530), new Point(530, 530) }, // Jugador 3 (verde)
        new[] { new Point(50, 500), new Point(80, 500), new Point(50, 530), new Point(80, 530) }    // Jugador 4 (amarillo)
    };

            return initialPositions[playerIndex][pieceIndex];
        }

        private Color GetPlayerColor(int playerIndex)
        {
            switch (playerIndex)
            {
                case 0:
                    return Color.Red; // Jugador 1
                case 1:
                    return Color.Blue; // Jugador 2
                case 2:
                    return Color.Green; // Jugador 3
                case 3:
                    return Color.Yellow; // Jugador 4
                default:
                    return Color.Black; // Color predeterminado
            }
        }

        private void RollDiceButton_Click(object sender, EventArgs e)
        {
            if (!isMyTurn)
            {
                MessageBox.Show("No es tu turno. Por favor, espera.");
                return;
            }

            // Generar número entre 1 y 6
            diceResult = random.Next(1, 7);
            diceResultLabel.Text = "Dado: " + diceResult;

            // Enviar resultado al servidor
            SendToServer($"ROLL_DICE|{playerID}|{diceResult}");
        }

        private void SendToServer(string message)
        {
            try
            {
                byte[] data = Encoding.UTF8.GetBytes(message);
                clientSocket.Send(data);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al enviar datos al servidor: " + ex.Message);
            }
        }

        private void StartListeningToServer()
        {
            Task.Run(() =>
            {
                while (true)
                {
                    try
                    {
                        byte[] buffer = new byte[1024];
                        int bytesRead = clientSocket.Receive(buffer);
                        string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        ProcessServerMessage(message);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al recibir datos del servidor: " + ex.Message);
                        break;
                    }
                }
            });
        }

        private void ProcessServerMessage(string message)
        {
            string[] parts = message.Split('|');
            string command = parts[0];

            switch (command)
            {
                case "UPDATE_PIECE":
                    int player = int.Parse(parts[1]);
                    int piece = int.Parse(parts[2]);
                    int position = int.Parse(parts[3]);
                    UpdatePiecePosition(player, piece, position);
                    break;

                case "START_TURN":
                    isMyTurn = true;
                    MessageBox.Show("Es tu turno. Lanza el dado.");
                    break;

                case "END_TURN":
                    isMyTurn = false;
                    MessageBox.Show("Esperando el turno de otros jugadores.");
                    break;
                case "START_GAME":
                    string[] initialBoardState = parts[1].Split(',');
                    int currentTurn = int.Parse(parts[2]);

                    this.Invoke((MethodInvoker)delegate
                    {
                        this.Hide();
                        Form6 gameForm = new Form6(clientSocket, playerID, initialBoardState, currentTurn);
                        gameForm.Show();
                    });

                    break;

                case "41": // Actualización del tablero
                           // Aquí manejarás actualizaciones del estado del tablero
                    UpdateBoardState(parts[1]);
                    break;

                default:
                    MessageBox.Show("Comando desconocido: " + command);
                    break;
            }
        }
    

        private void UpdatePiecePosition(int playerIndex, int pieceIndex, int boardPosition)
        {
            playerPieces[playerIndex][pieceIndex].Location = boardPositions[boardPosition];
        }
        private void MovePlayerPiece(int playerIndex, int pieceIndex, int steps)
        {
            // Verifica que los índices son válidos
            if (playerIndex < 0 || playerIndex >= playerPieces.Length)
                throw new IndexOutOfRangeException("Índice de jugador fuera de rango.");

            if (pieceIndex < 0 || pieceIndex >= playerPieces[playerIndex].Length)
                throw new IndexOutOfRangeException("Índice de ficha fuera de rango.");

            // Obtener la posición actual
            var piece = playerPieces[playerIndex][pieceIndex];
            int currentPosition = Array.IndexOf(boardPositions, piece.Location);

            if (currentPosition == -1)
                throw new InvalidOperationException("Ficha no está en una posición válida.");

            // Calcular nueva posición
            int newPosition = (currentPosition + steps) % boardPositions.Length;

            // Mover ficha
            piece.Location = boardPositions[newPosition];
        }
        private void InitializeBoardState(string[] boardState, int currentTurn)
        {
            for (int i = 0; i < boardState.Length; i++)
            {
                int position = int.Parse(boardState[i]);
                if (position != -1)
                {
                    MovePlayerPiece(i / 4, i % 4, position); // Coloca las fichas en sus posiciones iniciales
                }
            }

            // Configurar el turno inicial
            currentPlayer = currentTurn;
            currentPlayerLabel.Text = "Turno: Jugador " + currentPlayer;
        }
        private void UpdateBoardState(string boardState)
        {
            string[] positions = boardState.Split(',');

            for (int i = 0; i < positions.Length; i++)
            {
                int position = int.Parse(positions[i]);
                if (position != -1)
                {
                    MovePlayerPiece(i / 4, i % 4, position); // Coloca las fichas en sus posiciones iniciales
                }
            }
        }

    }
}

