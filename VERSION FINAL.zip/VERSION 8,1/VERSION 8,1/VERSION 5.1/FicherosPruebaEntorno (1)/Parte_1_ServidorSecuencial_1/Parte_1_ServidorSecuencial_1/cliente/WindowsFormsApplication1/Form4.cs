﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form4 : Form
    {
        private string nombreUsuario;
        private Socket server;
        public Form4()
        {
            InitializeComponent();
        }
        public void SetData(DataTable data)
        {
           dataGridView4.DataSource = data;
        }
    }

}
