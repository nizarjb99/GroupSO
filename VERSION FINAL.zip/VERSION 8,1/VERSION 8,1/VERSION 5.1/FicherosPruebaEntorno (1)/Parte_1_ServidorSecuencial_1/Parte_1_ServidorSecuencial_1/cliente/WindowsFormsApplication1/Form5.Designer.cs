﻿namespace WindowsFormsApplication1
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewBloqueados = new System.Windows.Forms.DataGridView();
            this.Nombre_Usuario = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desbloquearBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBloqueados)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewBloqueados
            // 
            this.dataGridViewBloqueados.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridViewBloqueados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBloqueados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Nombre_Usuario});
            this.dataGridViewBloqueados.Location = new System.Drawing.Point(74, 106);
            this.dataGridViewBloqueados.Name = "dataGridViewBloqueados";
            this.dataGridViewBloqueados.ReadOnly = true;
            this.dataGridViewBloqueados.RowHeadersWidth = 51;
            this.dataGridViewBloqueados.RowTemplate.Height = 24;
            this.dataGridViewBloqueados.Size = new System.Drawing.Size(667, 177);
            this.dataGridViewBloqueados.TabIndex = 42;
            this.dataGridViewBloqueados.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewBloqueados_CellContentClick);
            // 
            // Nombre_Usuario
            // 
            this.Nombre_Usuario.HeaderText = "Nombre_Usuario";
            this.Nombre_Usuario.MinimumWidth = 6;
            this.Nombre_Usuario.Name = "Nombre_Usuario";
            this.Nombre_Usuario.ReadOnly = true;
            this.Nombre_Usuario.Width = 125;
            // 
            // desbloquearBtn
            // 
            this.desbloquearBtn.Location = new System.Drawing.Point(302, 324);
            this.desbloquearBtn.Name = "desbloquearBtn";
            this.desbloquearBtn.Size = new System.Drawing.Size(223, 61);
            this.desbloquearBtn.TabIndex = 43;
            this.desbloquearBtn.Text = "Desbloquear";
            this.desbloquearBtn.UseVisualStyleBackColor = true;
            this.desbloquearBtn.Click += new System.EventHandler(this.desbloquearBtn_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.desbloquearBtn);
            this.Controls.Add(this.dataGridViewBloqueados);
            this.Name = "Form5";
            this.Text = "Form5";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBloqueados)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewBloqueados;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre_Usuario;
        private System.Windows.Forms.Button desbloquearBtn;
    }
}