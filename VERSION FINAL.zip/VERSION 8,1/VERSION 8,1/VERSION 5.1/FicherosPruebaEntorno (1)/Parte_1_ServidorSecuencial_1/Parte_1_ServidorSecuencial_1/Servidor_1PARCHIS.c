#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <mysql/mysql.h>
#include <pthread.h>
#define BUFFER_SIZE 1024
#include <stdlib.h>
#include <time.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;



typedef struct {
	char nombre[1500];
	int socket;	
	int Sala;
} Conectado;

typedef struct {
	Conectado listaConectado[500];
	int num;
} listaConectados;

typedef struct {
	char id[1500];  
	char jugadores[1500];
	int num;	
} Invitacion;

typedef struct {
	Invitacion listaInvitaciones[500]; 
	int num;
} listaInvitaciones;

typedef struct {
	int Id;
	Conectado listaPartda[500];
	int num;
} Partida;

typedef struct {
	int posiciones[16]; // 4 fichas por 4 jugadores
	int turnoActual;    // Jugador con el turno actual (1-4)
} Tablero;

typedef struct {
	Partida listaPartdas[500];
	int num;
} listaPartdas;
char ubi[20];
int i = 0;
int sockets[100];
int turno = 1;

listaConectados listaConec;
listaInvitaciones listaInvit;
listaPartdas listaPart;


int EsMovimientoValido(Tablero *tablero, int idFicha, int nuevaPosicion) {
	// Verifica si la casilla está ocupada por dos fichas del mismo jugador
	int jugador = idFicha / 4; // Calcula el jugador basado en la ficha (0-3)
	int bloqueadas = 0;
	
	for (int i = jugador * 4; i < (jugador + 1) * 4; i++) {
		if (tablero->posiciones[i] == nuevaPosicion) {
			bloqueadas++;
		}
	}
	if (bloqueadas >= 2) {
		return 0; // Casilla bloqueada por el mismo jugador
	}
	
	return 1; // Movimiento permitido
}

void ActualizarPosicionFicha(Tablero *tablero, int idFicha, int nuevaPosicion) {
	tablero->posiciones[idFicha] = nuevaPosicion;
}


void CambiarTurno(Tablero *tablero) {
	tablero->turnoActual = (tablero->turnoActual % 4) + 1; // Cicla entre 1 y 4
}

void NotificarEstadoTablero(Tablero *tablero, int *sockets, int numJugadores) {
	char notificacion[BUFFER_SIZE];
	sprintf(notificacion, "41/");
	
	// Añadir posiciones de todas las fichas
	for (int i = 0; i < 16; i++) {
		char buffer[10];
		sprintf(buffer, "%d,", tablero->posiciones[i]);
		strcat(notificacion, buffer);
	}
	// Añadir turno actual
	char turnoBuffer[10];
	sprintf(turnoBuffer, "%d", tablero->turnoActual);
	strcat(notificacion, turnoBuffer);
	
	// Enviar a todos los jugadores
	for (int i = 0; i < numJugadores; i++) {
		write(sockets[i], notificacion, strlen(notificacion));
	}
}

void ProcesarMovimientoFicha(char *buff, int sock_conn, Tablero *tablero, int *sockets, int numJugadores) {
	int idJugador, idFicha, nuevaPosicion;
	sscanf(buff, "40/%d/%d/%d", &idJugador, &idFicha, &nuevaPosicion);
	
	if (tablero->turnoActual != idJugador) {
		char respuesta[BUFFER_SIZE];
		sprintf(respuesta, "40/0/No es tu turno");
		write(sock_conn, respuesta, strlen(respuesta));
		return;
	}
	if (EsMovimientoValido(tablero, idFicha, nuevaPosicion)) {
		ActualizarPosicionFicha(tablero, idFicha, nuevaPosicion);
		char respuesta[BUFFER_SIZE];
		sprintf(respuesta, "40/1/Movimiento exitoso");
		write(sock_conn, respuesta, strlen(respuesta));
		
		// Notificar a todos el nuevo estado del tablero
		NotificarEstadoTablero(tablero, sockets, numJugadores);
		
		// Cambiar turno
		CambiarTurno(tablero);
	} else {
		char respuesta[BUFFER_SIZE];
		sprintf(respuesta, "40/0/Movimiento inválido");
		write(sock_conn, respuesta, strlen(respuesta));
	}
}



void InicializarTablero(Tablero *tablero) {
	for (int i = 0; i < 16; i++) {
		tablero->posiciones[i] = -1; // Todas las fichas comienzan en "casa"
	}
	tablero->turnoActual = 1; // Empieza el jugador 1
}

void InicializarListas() {
	listaConec.num = 0;
	listaPart.num = 0;
	listaInvit.num = 0;
}

int AnadirUsuario(listaConectados *lista, char nombre[20], int socket) {
	if (lista->num == 500) return -1; 
	else 
	{
		strcpy(lista->listaConectado[lista->num].nombre, nombre);
		lista->listaConectado[lista->num].socket = socket;
		lista->listaConectado[lista->num].Sala = 0;
		lista->num++;
		printf("Usuario '%s' a�adido a la lista de conectados.\n", nombre);
		printf("N�mero de usuarios conectados: %d\n", lista->num);
		return 0; 
	}
}

int PosicionUsuario(listaConectados *lista, char nombre[20]) {
	for (int i = 0; i < lista->num; i++) 
	{
		if (strcmp(lista->listaConectado[i].nombre, nombre) == 0) return i;
	}
	return -1;
}

int EliminarUsuario(listaConectados *lista, char nombre[20]) {
	int posi = PosicionUsuario(lista, nombre);
	if (posi == -1 || posi >= lista->num) // Verifica si la posiicion es valida
		return -1;
	else 
	{
		for (int i = posi; i < lista->num - 1; i++) 
		{ 
			lista->listaConectado[i] = lista->listaConectado[i + 1];
		}
		lista->num--;
		printf("Usuario '%s' eliminado de la lista de conectados.\n", nombre);
		printf("Numero de usuarios conectados: %d\n", lista->num);
		return 0;
	}
}


int DameUsuarios(listaConectados *lista, char listaConectado[300]) {
	strcpy(listaConectado, "");
	char name[50];
	int n;
	for (int i = 0; i < lista->num; i++) 
	{		
		sprintf(name, "%s/", lista->listaConectado[i].nombre);
		strcat(listaConectado, name);
		n = i;
	}
	printf("Usuarios conectados: '%s'\n", listaConectado);
	printf("\n");
	return n;
}

void EnviarConectados(char mensaje[500]) {
	char conectados[512];   
	char connected[512];
	
	int n = DameUsuarios(&listaConec, conectados);
	
	sprintf(mensaje, "6/%s", conectados);
	printf("Mensaje lista de conectados: %s\n", mensaje);
	strcpy(connected, conectados);
	char *y = strtok(connected, "/");
	int i = 0;
	while (y != NULL && i < n) 
	{
		char nombre[50]; 
		strncpy(nombre, y, sizeof(nombre) - 1); 
		nombre[sizeof(nombre) - 1] = '\0';
		y = strtok(NULL, "/");
		i++;
	}
}


int EstaConectado(listaConectados *lista, char nombreUsuario[20]) {
	for (int i = 0; i < lista->num; i++) 
	{
		if (strcmp(lista->listaConectado[i].nombre, nombreUsuario) == 0) return 0;
	}
	return -1;
}

int Dame_Socket(listaConectados *lista, char nombre[20]) {
	for (int i = 0; i < lista->num; i++) {
		if (strcmp(lista->listaConectado[i].nombre, nombre) == 0) return lista->listaConectado[i].socket;
	}
	return -1;
}

void PonerSala(listaConectados *lista, char nombre[1500]){	
	int posi = PosicionUsuario(lista, nombre);
	lista->listaConectado[posi].Sala = 1;
}

void QuitarSala(listaConectados *lista, char nombre[1500]){
	int posi = PosicionUsuario(lista, nombre);
	lista->listaConectado[posi].Sala = 0;	
}

int EstaEnSala(listaConectados *lista, char nombre[1500]){
	int posi = PosicionUsuario(lista, nombre);
	return lista->listaConectado[posi].Sala;
}

int CrearSala(listaInvitaciones *lista, listaConectados *list_2, char nombre[1500]){
	int DentroSala = EstaEnSala(list_2, nombre);
	if(DentroSala == 1){
		printf("El usuario '%s' ya esta en una sala.\n", nombre);
		return -1;	
	}
	printf("Sala creada con exito: '%s'\n", nombre);	
	strcpy(lista->listaInvitaciones[lista->num].id, nombre);
	sprintf(lista->listaInvitaciones[lista->num].jugadores, "%s-", nombre);
	PonerSala(list_2, nombre);
	lista->listaInvitaciones[lista->num].num = 1;
	lista->num++;	
	return 1;
}

int VerSala(listaInvitaciones *lista, char invitador[1500], char jugadores[1500]){
	int posi;
	for (int i = 0; i < lista->num; i++) 
	{
		if(strcmp(lista->listaInvitaciones[i].id, invitador)==0) posi = i;
	}	
	strcpy(jugadores, lista->listaInvitaciones[posi].jugadores);
	return lista->listaInvitaciones[posi].num;
}

int EstaEnLaSala(listaInvitaciones *lista, char admin[1500], char invitado[1500]){
	char jugadores[1500];
	char jugadores_2[1500];
	VerSala(lista, admin, jugadores);
	strcpy(jugadores_2, jugadores);
	
	char *p = strtok(jugadores_2, "-");
	while (p != NULL) 
	{
		if(strcmp(p, invitado) == 0) return 1;
		p = strtok(NULL, "-");
	}	
	return -1;
}

int AnadirASala(listaInvitaciones *lista, listaConectados *list_2, char invitador[1500], char invitado[1500]){
	int estaEnLaSala = EstaEnLaSala(lista, invitador, invitado);
	if(estaEnLaSala == 1) return -1; // Invitado ya esta en la sala.
	
	int posi;
	for (int i = 0; i < lista->num; i++) 
	{
		if(strcmp(lista->listaInvitaciones[i].id, invitador)==0) posi = i;
	}	
	
	if(lista->listaInvitaciones[posi].num <4)
	{
		sprintf(lista->listaInvitaciones[posi].jugadores, "%s%s-", lista->listaInvitaciones[posi].jugadores, invitado);		
		lista->listaInvitaciones[posi].num++;
		PonerSala(list_2, invitado);
		return 1;
	}	
	else return 0; // La sala est� llena
}


int EliminarSala(listaInvitaciones *lista, listaConectados *list_2, char nombre[1500]){
	int posi;
	for (int i = 0; i < lista->num; i++) 
	{
		posi = i;
		if(strcmp(lista->listaInvitaciones[i].id, nombre)==0)
		{			
			char jugadores[1500];
			char jugadores_2[1500];
			VerSala(lista, nombre, jugadores);
			strcpy(jugadores_2, jugadores);
			char *p = strtok(jugadores_2, "-");
			while(p!= NULL){
				QuitarSala(list_2, p);
				p = strtok(NULL, "-");				
			}
			
			for (int i = posi; i < lista->num - 1; i++) 
			{ 
				lista->listaInvitaciones[i] = lista->listaInvitaciones[i + 1];
			}
			lista->num--;
			printf("Sala eliminada con exito: '%s'\n", nombre);					
			return 1;
		}
	}	
	return -1;	
}

int AbandonarSala(listaInvitaciones *lista, listaConectados *list_2, char nombre[1500], char nombreSala[1500]){
	int estaEnLaSala = EstaEnLaSala(lista, nombreSala, nombre);
	if(estaEnLaSala == 1){
		int posi;
		for (int i = 0; i < lista->num; i++) 
		{
			posi = i;
			if(strcmp(lista->listaInvitaciones[i].id, nombreSala)==0)
			{		
				printf("'%s' ha abandonado la sala con exito: \n", nombre);			
				lista->listaInvitaciones[posi].num--;
				
				char jugador[200];
				char jugadores[1500];
				char listaJugadores[1500];
				VerSala(&listaInvit, nombreSala, jugadores);
				strcpy(listaJugadores, jugadores);
				sprintf(jugador, "%s-",nombre);
				
				char *posii = strstr(listaJugadores, jugador); // Encuentra la subcadena en la cadena original
				
				if (posii != NULL) {
					size_t len = strlen(jugador);
					size_t len_cadena = strlen(listaJugadores);
					
					
					memmove(posii, posii + len, len_cadena - len - (posii - listaJugadores) + 1);
				}
				strcpy(lista->listaInvitaciones[i].jugadores, listaJugadores);
				QuitarSala(list_2, nombre);		
				return 1;
			}
		}	
	}
	return -1;	
}


int SalaLlena(listaInvitaciones *lista, char admin[1500]){
	int posi;
	for (int i = 0; i < lista->num; i++) 
	{
		if(strcmp(lista->listaInvitaciones[i].id, admin)==0) posi = i;
	}			
	if(lista->listaInvitaciones[posi].num >= 4) return 1;
	else return 0;
}

int EsAdmin(listaInvitaciones *lista, char nombre[1500]){
	for (int i = 0; i < lista->num; i++) 
	{
		if (strcmp(lista->listaInvitaciones[i].id, nombre) == 0) return 1;
	}
	return 0;
}

int Dame_Sockets_Sala(listaInvitaciones *lista, listaConectados *list_2, char id[200], char Sockets_Jugadores[400], char jugadores[1500]) {
	int posi = -1;
	int nJugadores = 0;    
	
	for (int i = 0; i < lista->num; i++) 
	{
		if (strcmp(lista->listaInvitaciones[i].id, id) == 0) posi = i;
	}
	
	if (posi == -1) 
	{
		printf("No se encontr� la invitaci�n con id %s\n", id);
		return -1;
	}
	
	strcpy(jugadores, lista->listaInvitaciones[posi].jugadores);
	
	char jugadores_2[1500];
	strcpy(jugadores_2, jugadores);
	
	char *p = strtok(jugadores, "-");
	while (p != NULL) 
	{
		nJugadores++;
		p = strtok(NULL, "-");
	}	
	char Sockets_Jugadores_Sala[400] = "";
	char *l = strtok(jugadores_2, "-");
	int sock = Dame_Socket(list_2, l);
	sprintf(Sockets_Jugadores_Sala, "%d", sock);
	l = strtok(NULL, "-");
	
	for (int i = 0; i < nJugadores; i++) 
	{
		if (l == NULL) break;		
		sock = Dame_Socket(list_2, l);
		sprintf(Sockets_Jugadores_Sala, "%s-%d", Sockets_Jugadores_Sala, sock);
		l = strtok(NULL, "-");
	}
	
	strcpy(Sockets_Jugadores, Sockets_Jugadores_Sala);
	
	return nJugadores;
}


int Dame_Numero_Jugadores_Sala(listaInvitaciones *lista, char id[200], int *nJugadores) {
	int posi = -1;
	
	// Buscar la invitaci�n en la lista de invitaciones
	for (int i = 0; i < lista->num; i++) 
	{
		if (strcmp(lista->listaInvitaciones[i].id, id) == 0) 
		{
			posi = i;
			break; // No es necesario seguir buscando
		}
	}
	
	// Si no se encontr� la invitaci�n, devolver -1
	if (posi == -1) 
	{
		printf("No se encontr� la invitaci�n con id %s\n", id);
		return -1;
	}
	
	// Coyar la lista de jugadores de la invitaci�n encontrada
	char jugadores[1500];
	strcpy(jugadores, lista->listaInvitaciones[posi].jugadores);
	
	// Contar el n�mero de jugadores
	*nJugadores = 0;
	char *p = strtok(jugadores, "-");
	while (p != NULL) 
	{
		(*nJugadores)++;
		p = strtok(NULL, "-");
	}
	
	return 0; // Retorno 0 para indicar �xito
}


int IsUserBlocked(MYSQL *conn, const char *Nombre_Usuario){
	char query[512];
	snprintf(query, sizeof(query), "SELECT Bloqueado FROM Usuario WHERE Nombre_Usuario = '%s';", Nombre_Usuario);
	
	if (mysql_query(conn,query) != 0){
		printf("Error al verificar estado de bloqueo: %s\n", mysql_error(conn));
		return -1; //Error
	}
	
	MYSQL_RES *result = mysql_store_result(conn);
	if(result == NULL){
		printf("Error al obtener resultados: %s\n", mysql_error(conn));
		return -1; //Error
	}
	
	MYSQL_ROW row = mysql_fetch_row(result);
	int isBlocked = (row && atoi(row[0]) == 1) ? 1: 0;
	mysql_free_result(result);
	
	return isBlocked;
}


void HandleBlockCommand(char *buff, MYSQL *conn, int clientSocket){
	char *username = strtok(NULL, "/"); // Nombre del usuario a bloquear
	if (username == NULL)
	{
		printf("Error: Nombre de usuario no especificado para bloqueo.\n");
		return;
	}
	
	// Consulta para bloquear al usuario
	char query[512];
	snprintf(query, sizeof(query), "UPDATE Usuario SET Bloqueado = 1 WHERE Nombre_Usuario = '%s';", username);
	
	// Ejecutar la consulta
	if (mysql_query(conn, query) == 0)
	{
		printf("Usuario '%s' bloqueado exitosamente.\n", username);
		
		// Enviar respuesta de éxito al cliente
		char response[] = "BLOCK/1";
		write(clientSocket, response, strlen(response));
	}
	else
	{
		printf("Error al bloquear al usuario: %s\n", mysql_error(conn));
		
		// Enviar respuesta de error al cliente
		char response[] = "BLOCK/0";
		write(clientSocket, response, strlen(response));
	}
}

void IniciarPartida(listaInvitaciones *lista, listaConectados *listaConectados, char admin[1500]) {
	char jugadores[1500];
	char Sockets_Jugadores[400];
	int nJugadores = Dame_Sockets_Sala(lista, listaConectados, admin, Sockets_Jugadores, jugadores);
	
	if (nJugadores <= 0) {
		printf("Error: No hay jugadores en la sala.\n");
		return;
	}
//Crear notificación de inicio
		char notificacion[200];
	sprintf(notificacion, "START_GAME/%s", jugadores); // Puede incluir estado inicial del tablero
	
	// Enviar a todos los jugadores
	char *l = strtok(Sockets_Jugadores, "-");
	while (l != NULL) {
		int socket_actual = atoi(l);
		printf("Enviando inicio de partida a socket: %d\n", socket_actual);
		int bytes_enviados = write(socket_actual, notificacion, strlen(notificacion));
		if (bytes_enviados <= 0) {
			printf("Error al enviar datos al cliente\n");
		}
		l = strtok(NULL, "-");
	}
}

void ProcesarReady(listaInvitaciones *lista, listaConectados *listaConectados, char admin[1500]) {
	// Contar jugadores listos en la sala
	char jugadores[1500];
	int nJugadores = VerSala(lista, admin, jugadores);
	// Si todos están listos, inicia la partida
	if (nJugadores > 1) { // Asegurate de tener al menos 2 jugadores
		IniciarPartida(lista, listaConectados, admin);
	} else {
		printf("Aún no están todos listos.\n");
	}
}
void *AtenderCliente(void *socket) 
{	
	strcpy(ubi, "localhost");
	
	char nomUsuario[20];
	char contra[20];
	char correo[50];
	int ret;
	char buff[512];
	char peticion[512];
	/*char res[512];*/
	int sock_conn = *((int *)socket);
	printf("Socket del cliente: %d\n", sock_conn);
	
	//Inicio el MYSQL
	MYSQL *conn;
	int err;
	// Estructura necessaria para acesso excluyente
	pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
	
	// Estructura especial para almacenar resultados de consultas 
	MYSQL_RES *resultado;
	MYSQL_ROW row;
	//Creamos una conexion al servidor MYSQL 
	conn = mysql_init(NULL);
	if (conn==NULL) {
		printf ("Error al crear la conexion: %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit(1);
	}
	
	// Conectar con el servidor MySQL
	if (mysql_real_connect(conn, ubi, "root", "mysql", "BBDD_PARCHIS", 0, NULL, 0) == NULL) 
	{
		printf("Error al conectar con el servidor MySQL\n");
		mysql_close(conn);
		close(sock_conn);
		pthread_exit(NULL);
	}
	
	int terminar = 0;
	while (terminar ==0) 
	{
		ret = read(sock_conn, buff, sizeof(buff));	
		buff[ret]='\0';				
		printf ("------------------------------------------\nPeticion recibida: %s\n",buff);
		
		// Procesar las peticiones del cliente segun el codigo recibido
		char *p = strtok(buff, "/");
		if (p == NULL) {
			printf("Error: Codigo no especificado.\n");
			break;
		}
		int codigo = atoi(p);
		
		if(codigo == -2){ //Darse de baja
			
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Correo no especificado.\n");
				break;
			}
			strcpy(correo, p);
			
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Usuario no especificado.\n");
				break;
			}
			strcpy(nomUsuario, p);
			
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Contrase�a no especificada.\n");
				break;
			}
			strcpy(contra, p);			
			
			int estaConectado = EstaConectado(&listaConec, nomUsuario);
			if(estaConectado==-1){
				char consulta[1000];
				strcpy(consulta, "SELECT * FROM Usuario WHERE Nombre_Usuario = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' AND Passwd = '");
				strcat(consulta, contra);
				strcat(consulta, "' AND Correo = '");
				strcat(consulta, correo);
				strcat(consulta, "';");
				
				int err = mysql_query(conn, consulta);
				if (err != 0) 
				{
					printf("Error al consultar datos de la base: %u %s\n", mysql_errno(conn), mysql_error(conn));
					close(sock_conn);
					pthread_exit(NULL);
				}
				
				resultado = mysql_store_result(conn);
				int n_rows = mysql_num_rows(resultado);
				
				if (n_rows > 0) 
				{
					// Insertar el usuario en la base de datos
					char consulta2[1000];
					strcpy(consulta2, "DELETE FROM Usuario WHERE Nombre_Usuario = '");
					strcat(consulta2, nomUsuario);
					strcat(consulta2, "';");
					
					err = mysql_query(conn, consulta2);
					if (err != 0) 
					{
						printf("Error al insertar datos en la base: %u %s\n", mysql_errno(conn), mysql_error(conn));
						close(sock_conn);
						pthread_exit(NULL);
					}
					
					printf("Usuario dado de baja con exito!\n");
					strcpy(buff, "-2/1");			
					
					int bytes_enviados = write(sock_conn, buff, strlen(buff));
					if (bytes_enviados <= 0) 
					{
						printf("Error al enviar datos al cliente\n");
					}
				}
				else{
					printf("Este usuario no existe!\n");
					strcpy(buff, "-2/-1");			
					
					int bytes_enviados = write(sock_conn, buff, strlen(buff));
					if (bytes_enviados <= 0) 
					{
						printf("Error al enviar datos al cliente\n");
					}
				}
			}
			else{
				printf("Este usuario esta conectado\n");
				strcpy(buff, "-2/-2");			
				
				int bytes_enviados = write(sock_conn, buff, strlen(buff));
				if (bytes_enviados <= 0) 
				{
					printf("Error al enviar datos al cliente\n");
				}
			}
			
		}
		if (codigo == -1) // Desconexion
		{
			close(sock_conn);
			terminar = 1;
		}
		
		else if (codigo == 0) // Desconexion del cliente
		{ 
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Usuario no especificado.\n");
				break;
			}
			strcpy(nomUsuario, p);
			
			/*int eliminar = */EliminarUsuario(&listaConec, nomUsuario);
			
			// Enviar lista de usuarios conectados a todos los clientes
			EnviarConectados(peticion);		
			
			for (int i = 0; i < listaConec.num; i++) 
			{
				int bytes_enviados = write(listaConec.listaConectado[i].socket, peticion, strlen(peticion));
				if (bytes_enviados <= 0) 
				{
					printf("Error al enviar datos al cliente\n");
				}
			}		
			printf("Lista de conectados actualizada enviada a todos los usuarios conectados!\n");
			close(sock_conn);
			terminar = 1;
		}
		
		else if (codigo == 1) 
		{			
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Correo no especificado.\n");
				break;
			}
			strcpy(correo, p);
			
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Usuario no especificado.\n");
				break;
			}
			strcpy(nomUsuario, p);
			
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Contrase�a no especificada.\n");
				break;
			}
			strcpy(contra, p);			
			
			char consulta1[1000];
			strcpy(consulta1, "SELECT * FROM Usuario WHERE Nombre_Usuario = '");
			strcat(consulta1, nomUsuario);
			strcat(consulta1, "';");
			
			int err = mysql_query(conn, consulta1);
			if (err != 0) 
			{
				printf("Error al consultar datos de la base: %u %s\n", mysql_errno(conn), mysql_error(conn));
				close(sock_conn);
				pthread_exit(NULL);
			}
			
			resultado = mysql_store_result(conn);
			int n_rows = mysql_num_rows(resultado);
			
			if (n_rows == 0) 
			{
				// Insertar el usuario en la base de datos
				char consulta2[1000];
				strcpy(consulta2, "INSERT INTO Usuario (Nombre_Usuario, Correo, Passwd, Victorias) VALUES ('");
				strcat(consulta2, nomUsuario);
				strcat(consulta2, "', '");
				strcat(consulta2, correo);
				strcat(consulta2, "', '");
				strcat(consulta2, contra);
				strcat(consulta2, "', '0');");
				
				err = mysql_query(conn, consulta2);
				if (err != 0) 
				{
					printf("Error al insertar datos en la base: %u %s\n", mysql_errno(conn), mysql_error(conn));
					close(sock_conn);
					pthread_exit(NULL);
				}
				
				printf("Usuario registrado con exito!\n");
				strcpy(buff, "1/1");			
				
				int add = AnadirUsuario(&listaConec, nomUsuario, sock_conn);
				int bytes_enviados = write(sock_conn, buff, strlen(buff));
				if (bytes_enviados <= 0) 
				{
					printf("Error al enviar datos al cliente\n");
				}
				
				
				if (add != 0) 
				{
					printf("Error al agregar el usuario a la lista de conectados\n");
					close(sock_conn);
					pthread_exit(NULL);
				}
				
				// Enviar lista de usuarios conectados a todos los clientes
				EnviarConectados(peticion);
				
				for (int i = 0; i < listaConec.num; i++) 
				{
					int bytes_enviados = write(listaConec.listaConectado[i].socket, peticion, strlen(peticion));
					if (bytes_enviados <= 0) 
					{
						printf("Error al enviar datos al cliente\n");
					}
				}
				printf("Lista de conectados actualizada enviada a todos los usuarios conectados!\n");
			} 
			else 
			{
				strcpy(buff, "1/-1");
				printf("El usuario ya existe!\n");
				int bytes_enviados = write(sock_conn, buff, strlen(buff));
				if (bytes_enviados <= 0) 
				{
					printf("Error al enviar datos al cliente\n");
				}
			}			
		}
		
		//El usuario inicia sesion y se a�ade a la lista de conectados
		else if (codigo == 2) 
		{
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Usuario no especificado.\n");
				break;
			}
			strcpy(nomUsuario, p);
			
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Contrase�a no especificada.\n");
				break;
			}
			strcpy(contra, p);
			
			char consulta[1000];
			strcpy(consulta, "SELECT Nombre_Usuario FROM Usuario WHERE Nombre_Usuario = '");
			strcat(consulta, nomUsuario);
			strcat(consulta, "' AND Passwd = '");
			strcat(consulta, contra);
			strcat(consulta, "';");
			
			err = mysql_query(conn, consulta);
			if (err != 0) 
			{
				printf("Error al consultar datos de la base: %u %s\n", mysql_errno(conn), mysql_error(conn));
				close(sock_conn);
				pthread_exit(NULL);
			}
			
			resultado = mysql_store_result(conn);
			row = mysql_fetch_row(resultado);
			
			if (row == NULL) 
			{
				strcpy(buff, "2/-1");
				printf("El usuario no existe o las credenciales son incorrectas\n");
				int bytes_enviados = write(sock_conn, buff, strlen(buff));
				if (bytes_enviados <= 0) 
				{
					printf("Error al enviar datos al cliente\n");
				}
			} 
			else 
			{
				int estaConectado = EstaConectado(&listaConec, nomUsuario);
				
				if (estaConectado == 0) {
					strcpy(buff, "2/-2");
					printf("Este usuario ya est� conectado.\n");
					int bytes_enviados = write(sock_conn, buff, strlen(buff));
					if (bytes_enviados <= 0) 
					{
						printf("Error al enviar datos al cliente\n");
					}
				} 
				else 
				{
					strcpy(buff, "2/1");
					printf("Usuario autenticado con exito\n");
					
					/*int add =*/ AnadirUsuario(&listaConec, nomUsuario, sock_conn);	
					int bytes_enviados = write(sock_conn, buff, strlen(buff));
					if (bytes_enviados <= 0) 
					{
						printf("Error al enviar datos al cliente\n");
					}
					
					// Enviar lista de usuarios conectados a todos los clientes
					EnviarConectados(peticion);
					
					for (int i = 0; i < listaConec.num; i++) 
					{
						int bytes_enviados = write(listaConec.listaConectado[i].socket, peticion, strlen(peticion));
						if (bytes_enviados <= 0) 
						{
							printf("Error al enviar datos al cliente\n");
						}
					}
					printf("Lista de conectados actualizada enviada a todos los usuarios conectados!\n");
				}
			}
		}
		
		else if(codigo == 3) // Crear sala: 3/Admin sala
		{
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Usuario no especificado.\n");
				break;
			}
			strcpy(nomUsuario, p);				
			
			char notificacion[20];
			int crear = CrearSala(&listaInvit, &listaConec, nomUsuario);
			if(crear == 1) sprintf(notificacion, "3/1");
			else strcpy(notificacion, "3/-1");
			
			int bytes_enviados = write(sock_conn, notificacion, strlen(notificacion));
			if (bytes_enviados <= 0) 
			{
				printf("Error al enviar datos al cliente\n");
			}		
			
			if(crear == 1)
			{
				char jugadores[1500];
				char listaJugadores[1500];
				VerSala(&listaInvit, nomUsuario, jugadores);
				sprintf(listaJugadores, "5/%s",jugadores);				
				printf("Envio lista de jugadores: '%s' por el socket: '%d'\n", listaJugadores, sock_conn);
				int bytes_enviados = write(sock_conn, listaJugadores, strlen(listaJugadores));
				if (bytes_enviados <= 0) 
				{
					printf("Error al enviar datos al cliente\n");
				}
			}			
		}
		
		else if (codigo == 4) // Abandonar o eliminar sala: 4/Usuario/Nombre sala
		{
			char notificacion[200];
			char notificacion2[200];
			char jugadores[1500];
			char listaJugadores[1500];
			
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Usuario no especificado.\n");
				break;
			}
			strcpy(nomUsuario, p);
			
			int esAdmin = EsAdmin(&listaInvit, nomUsuario);
			if (esAdmin == 1) 
			{
				strcpy(notificacion2, "10/La sala ha sido eliminada.");
				VerSala(&listaInvit, nomUsuario, jugadores);
				strcpy(listaJugadores, jugadores);
				char Sockets_Jugadores_Sala[400];
				int n = Dame_Sockets_Sala(&listaInvit, &listaConec, nomUsuario, Sockets_Jugadores_Sala, jugadores);
				
				if (n > 0) 
				{
					char *l = strtok(Sockets_Jugadores_Sala, "-");
					for (int i = 0; i < n; i++) 
					{
						if (l == NULL) break; // Verificar que l no sea NULL
						int socket_actual = atoi(l);
						printf("Envio notificaci�n de sala eliminada por el socket: '%d'\n", socket_actual);
						int bytes_enviados = write(socket_actual, notificacion2, strlen(notificacion2));
						if (bytes_enviados <= 0) {
							printf("Error al enviar datos al cliente\n");
						}
						l = strtok(NULL, "-");
					}
				}
				
				int eliminar = EliminarSala(&listaInvit, &listaConec, nomUsuario);
				if (eliminar == 1) strcpy(notificacion, "4/1");
				else strcpy(notificacion, "4/-1");
				
				int bytes_enviados = write(sock_conn, notificacion, strlen(notificacion));
				if (bytes_enviados <= 0) {
					printf("Error al enviar datos al cliente\n");
				}
			}
			else
			{
				int DentroSala = EstaEnSala(&listaConec, nomUsuario);
				if (DentroSala == 1)
				{
					char nombreSala[200];
					p = strtok(NULL, "/");
					if (p == NULL) {
						printf("Error: Nombre de sala no especificado.\n");
						strcpy(notificacion, "4/-1");
						int bytes_enviados = write(sock_conn, notificacion, strlen(notificacion));
						if (bytes_enviados <= 0) {
							printf("Error al enviar datos al cliente\n");
						}
					}
					strcpy(nombreSala, p);
					
					int abandonar = AbandonarSala(&listaInvit, &listaConec, nomUsuario, nombreSala);
					if (abandonar == 1) 
					{
						strcpy(notificacion, "4/1");
						int bytes_enviados = write(sock_conn, notificacion, strlen(notificacion));
						if (bytes_enviados <= 0) {
							printf("Error al enviar datos al cliente\n");
						}
						
						char jugadores[1500];
						char jugadores_2[1500];
						char notificacion_jugadores[1500];
						VerSala(&listaInvit, nombreSala, jugadores);
						strcpy(jugadores_2, jugadores);
						char Sockets_Jugadores_Sala[400];
						int n = Dame_Sockets_Sala(&listaInvit, &listaConec, nombreSala, Sockets_Jugadores_Sala, jugadores_2);
						sprintf(notificacion_jugadores, "5/%s", jugadores);
						
						printf("Sockets sala: %s\n", Sockets_Jugadores_Sala);
						printf("Jugadores sala: %s\n", jugadores);
						
						char *l = strtok(Sockets_Jugadores_Sala, "-");
						for (int i = 0; i < n; i++) {
							if (l == NULL) break;
							int socket_actual = atoi(l);
							printf("Envio notificaci�n lista de jugadores: '%s' por el socket: '%d'\n", notificacion_jugadores, socket_actual);
							int bytes_enviados_jugadores = write(socket_actual, notificacion_jugadores, strlen(notificacion_jugadores));
							if (bytes_enviados_jugadores <= 0) {
								printf("Error al enviar datos al cliente\n");
							}
							l = strtok(NULL, "-");
						}
						printf("Lista de jugadores actualizada enviada a todos los usuarios de la sala!\n");
					}
					else {
						strcpy(notificacion, "4/-1");
						int bytes_enviados = write(sock_conn, notificacion, strlen(notificacion));
						if (bytes_enviados <= 0) {
							printf("Error al enviar datos al cliente\n");
						}
					}
				}
				else
				{
					strcpy(notificacion, "4/-1");
					printf("El usuario '%s' no esta en ninguna sala.\n", nomUsuario);
					int bytes_enviados = write(sock_conn, notificacion, strlen(notificacion));
					if (bytes_enviados <= 0) {
						printf("Error al enviar datos al cliente\n");
					}
				}
			}
		}
		
		
		else if(codigo == 7) // Invitacion: 7/Persona que invita/Persona invitada
		{
			char invitador[200];
			p = strtok(NULL, "/");
			strcpy(invitador, p);
			
			char invitado[50];            
			p = strtok(NULL, "/");
			strcpy(invitado, p);    
			
			int salaLlena = SalaLlena(&listaInvit, invitador);
			if(salaLlena == 0){
				int Sala = EstaEnSala(&listaConec, invitado);
				if (Sala == 0) {
					char mensaje[200];    
					printf("'%s' ha invitado a jugar a '%s'.\n", invitador, invitado);    
					strcpy(mensaje, "Solicitud enviada.");
					snprintf(buff, sizeof(buff), "7/%s", mensaje);
					
					int bytes_enviados = write(sock_conn, buff, strlen(buff));
					if (bytes_enviados <= 0) {
						printf("Error al enviar datos al cliente\n");
					}
					
					char invitacion[200];
					snprintf(invitacion, sizeof(invitacion), "8/%s/%s", invitador, invitado);
					int sock_invitado = Dame_Socket(&listaConec, invitado);
					bytes_enviados = write(sock_invitado, invitacion, strlen(invitacion));
					if (bytes_enviados <= 0) {
						printf("Error al enviar datos al cliente\n");
					}
					printf("Se ha enviado la invitacion al usuario '%s' por el socket '%d'.\n", invitado, sock_invitado);             
				}
				else {
					char notificacion[200];
					snprintf(notificacion, sizeof(notificacion), "7/Invitacion invalida. '%s' ya esta en una sala.", invitado);
					int bytes_enviados = write(sock_conn, notificacion, strlen(notificacion));
					if (bytes_enviados <= 0) {
						printf("Error al enviar datos al cliente\n");
					}
					printf("No se ha podido invitar a '%s' porque ya est� en una sala.\n", invitado);
				}
			}
			else{
				char notif[200];
				strcpy(notif, "7/La sala esta llena.");           
				int bytes_enviados = write(sock_conn, notif, strlen(notif));
				if (bytes_enviados <= 0) {
					printf("Error al enviar datos al cliente\n");
				}
				printf("No se puede invitar, la sala esta llena.\n");
			}
		}
		
		else if (codigo == 8) // Aceptar o rechazar invitacion: 8/Persona que invita/Persona invitada/(1 o -1)
		{
			char invitador[200];
			p = strtok(NULL, "/");
			strcpy(invitador, p);
			
			char invitado[200];            
			p = strtok(NULL, "/");
			strcpy(invitado, p);
			
			int aceptada;
			int anadir;
			p = strtok(NULL, "/");
			aceptada = atoi(p);
			char notificacion[200];
			char notificacion2[200];
			char notificacion3[200];
			
			if (aceptada == 1) {
				anadir = AnadirASala(&listaInvit, &listaConec, invitador, invitado);    
				
				if (anadir == 1) {                            
					char jugadores[1500];
					char jugadores_2[1500];            
					VerSala(&listaInvit, invitador, jugadores);
					strcpy(jugadores_2, jugadores);
					char Sockets_Jugadores_Sala[400];
					int n = Dame_Sockets_Sala(&listaInvit, &listaConec, invitador, Sockets_Jugadores_Sala, jugadores_2);                 
					sprintf(notificacion3, "5/%s", jugadores); 
					printf("Sockets sala: %s\n", Sockets_Jugadores_Sala);
					printf("Jugadores sala: %s\n", jugadores);
					char *l = strtok(Sockets_Jugadores_Sala, "-");
					for (int i = 0; i < n; i++) {    
						if (l == NULL) break;
						int socket_actual = atoi(l);
						printf("Envio notificacion lista de jugadores: '%s' por el socket: '%d'\n", notificacion3, socket_actual);
						int bytes_enviados = write(socket_actual, notificacion3, strlen(notificacion3));
						if (bytes_enviados <= 0) {
							printf("Error al enviar datos al cliente\n");
						}
						l = strtok(NULL, "-");
					}
					printf("Lista de jugadores actualizada enviada a todos los usuarios de la sala!\n");
					
					sprintf(notificacion, "9/'%s' se ha unido a la sala.", invitado);
					printf("'%s' se ha unido a la sala.\n", invitado);
					
					// Notificación para todos los usuarios de la sala
					l = strtok(Sockets_Jugadores_Sala, "-");
					for (int i = 0; i < n; i++) {
						if (l == NULL) break;
						int socket_actual = atoi(l);
						int bytes_enviados = write(socket_actual, notificacion, strlen(notificacion));
						if (bytes_enviados <= 0) {
							printf("Error al enviar datos al cliente\n");
						}
						l = strtok(NULL, "-");
					}
					
					// Notificación específica para el invitado
					int sock_invitado = Dame_Socket(&listaConec, invitado);
					strcpy(notificacion2, "9/Te has unido a la sala.");
					int bytes_enviados = write(sock_invitado, notificacion2, strlen(notificacion2));
					if (bytes_enviados <= 0) {
						printf("Error al enviar datos al cliente\n");
					} 
				}
				else {
					strcpy(notificacion, "La sala esta llena, intentalo mas tarde.\n");                
					int sock_invitado = Dame_Socket(&listaConec, invitado);
					int bytes_enviados = write(sock_invitado, notificacion, strlen(notificacion));
					if (bytes_enviados <= 0) {
						printf("Error al enviar datos al cliente\n");
					}
				}
			}
			else {
				printf("'%s' ha rechazado la invitacion de union a la sala.\n", invitado);
				sprintf(notificacion, "9/'%s' ha rechazado la solicitud de union a la sala.", invitado);
				int sock_invitador = Dame_Socket(&listaConec, invitador);
				int bytes_enviados = write(sock_invitador, notificacion, strlen(notificacion));
				if (bytes_enviados <= 0) {
					printf("Error al enviar datos al cliente\n");
				}  
			}            
		}
		
		else if(codigo == 11) // Mensaje chat de sala: 11/Sala(0) o Juego(1)/Nombre admin/Emisor mensaje/Texto
		{			
			p = strtok(NULL, "/");
			int form = atoi(p);
			
			char nombreAdmin[200];			
			p = strtok(NULL, "/");
			strcpy(nombreAdmin, p);
			
			char emisorMensaje[200];			
			p = strtok(NULL, "/");
			strcpy(emisorMensaje, p);
			
			char texto [500];			
			p = strtok(NULL, "/");
			strcpy(texto, p);	
			
			char jugadores[1500];
			char jugadores_2[1500];
			char notificacion[1500];
			VerSala(&listaInvit, nombreAdmin, jugadores);
			strcpy(jugadores_2, jugadores);
			
			char Sockets_Jugadores_Sala[400];
			int n = Dame_Sockets_Sala(&listaInvit, &listaConec, nombreAdmin, Sockets_Jugadores_Sala, jugadores_2); 				
			sprintf(notificacion, "11/%d/%s|%s",form,emisorMensaje, texto);	
			
			printf("Sockets sala: %s\n", Sockets_Jugadores_Sala);
			printf("Jugadores sala: %s\n", jugadores);
			char *l = strtok(Sockets_Jugadores_Sala, "-");
			for (int i = 0; i < n; i++) {	
				if (l == NULL) break;
				int socket_actual = atoi(l);
				printf("Envio mensaje al chat de sala: '%s' por el socket: '%d'\n", notificacion, socket_actual);
				int bytes_enviados = write(socket_actual, notificacion, strlen(notificacion));
				if (bytes_enviados <= 0) 
				{
					printf("Error al enviar datos al cliente\n");
				}
				l = strtok(NULL, "-");
			}
			printf("Mensaje chat de sala enviado a todos los usuarios de la sala!\n");
		}
		
		else if(codigo == 12)
		{
			char invitador[200];
			p = strtok(NULL, "/");
			strcpy(invitador, p);
			
			char jugadores[1500];
			char jugadores_2[1500];
			char Sockets_Jugadores_Sala[400];
			int n = Dame_Sockets_Sala(&listaInvit, &listaConec, invitador, Sockets_Jugadores_Sala, jugadores_2);
			strcpy(jugadores, jugadores_2);
			
			char *l = strtok(Sockets_Jugadores_Sala, "-");
			char notif[200];
			int turno = 1;
			
			for (int i = 0; i < n; i++) 
			{
				if (l == NULL) break;
				int socket_actual = atoi(l);               
				sprintf(notif, "12/1/%s/%d/%d", invitador, turno, n);
				int bytes_enviados = write(socket_actual, notif, strlen(notif));
				printf("Se ha enviado %s por el socket: '%d'.\n",notif, socket_actual);
				if (bytes_enviados <= 0) 
				{
					printf("Error al enviar datos al cliente\n");
				}
				l = strtok(NULL, "-");
				turno += 1;
			}	
		}
		
		else if(codigo == 13) //
		{
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Consulta no especificada.\n");
				break;
			}
			int nConsulta = atoi(p);
			
			p = strtok(NULL, "/");
			if (p == NULL) {
				printf("Error: Usuario no especificado.\n");
				break;
			}
			strcpy(nomUsuario, p);				
			
			if (nConsulta == 1) 
			{ 
				char consulta[1500];
				strcpy(consulta, "SELECT DISTINCT Jugador FROM ("
					   "SELECT Jugador1 AS Jugador FROM Partida WHERE Jugador1 != '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' AND (Jugador2 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' OR Jugador3 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' OR Jugador4 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "') "
					   "UNION "
					   "SELECT Jugador2 AS Jugador FROM Partida WHERE Jugador2 != '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' AND (Jugador1 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' OR Jugador3 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' OR Jugador4 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "') "
					   "UNION "
					   "SELECT Jugador3 AS Jugador FROM Partida WHERE Jugador3 != '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' AND (Jugador1 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' OR Jugador2 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' OR Jugador4 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "') "
					   "UNION "
					   "SELECT Jugador4 AS Jugador FROM Partida WHERE Jugador4 != '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' AND (Jugador1 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' OR Jugador2 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "' OR Jugador3 = '");
				strcat(consulta, nomUsuario);
				strcat(consulta, "')) AS TodosLosJugadores;");
				
				int err = mysql_query(conn, consulta);
				if (err != 0) 
				{
					printf("Error al consultar datos de la base: %u %s\n", mysql_errno(conn), mysql_error(conn));
					close(sock_conn);
					pthread_exit(NULL);
				}
				
				resultado = mysql_store_result(conn);
				int n_rows = mysql_num_rows(resultado);
				char jugadores[1500];
				char mensaje[1500];
				if (n_rows > 0) 
				{
					while ((row = mysql_fetch_row(resultado))) 
					{
						sprintf(jugadores, "%s%s-", jugadores, row[0]);
						
					}
					sprintf(mensaje, "13/1/1/%s", jugadores);
					printf("Enviando mensaje: %s por el socket: '%d'\n", mensaje, sock_conn);
					int bytes_enviados = write(sock_conn, mensaje, strlen(mensaje));
					if (bytes_enviados <= 0) 
					{
						printf("Error al enviar datos al cliente\n");
					}
				}
				else
				{
					printf("'%s' no ha jugado con nadie todav�a.\n", nomUsuario);
					strcpy(buff, "13/1/-1");            
					
					int bytes_enviados = write(sock_conn, buff, strlen(buff));
					if (bytes_enviados <= 0) 
					{
						printf("Error al enviar datos al cliente\n");
					}
				}   
				strcpy(jugadores, "");
			}
			
			else if(nConsulta == 2){ // Resultados de las partidas que jug� con uno o m�s jugadores determinados.
				
				char jugadores[1000];
				p = strtok(NULL, "/");
				if (p == NULL) {
					printf("Error: Nombres de los jugadores no especificados.\n");
					break;
				}
				strcpy(jugadores, p);
				
				// Separar los nombres de los jugadores
				char *jugador;
				char condicion[4000] = "";
				jugador = strtok(jugadores, ",");
				while (jugador != NULL) {
					if (strlen(condicion) > 0) {
						strcat(condicion, " AND");
					}
					strcat(condicion, "(Jugador1 = '");
					strcat(condicion, jugador);
					strcat(condicion, "' OR Jugador2 = '");
					strcat(condicion, jugador);
					strcat(condicion, "' OR Jugador3 = '");
					strcat(condicion, jugador);
					strcat(condicion, "' OR Jugador4 = '");
					strcat(condicion, jugador);
					strcat(condicion, "')");
					jugador = strtok(NULL, ",");
				}
				
				char consulta2[5000];
				sprintf(consulta2, "SELECT * FROM Partida WHERE (Jugador1 = '%s' OR Jugador2 = '%s' OR Jugador3 = '%s' OR Jugador4 = '%s') AND (%s);",
						nomUsuario, nomUsuario, nomUsuario, nomUsuario, condicion);
				int err = mysql_query(conn, consulta2);
				if (err != 0) {
					printf("Error al consultar datos de la base: %u %s\n", mysql_errno(conn), mysql_error(conn));
					close(sock_conn);
					pthread_exit(NULL);
				}
				
				resultado = mysql_store_result(conn);
				int n_rows = mysql_num_rows(resultado);
				char mensaje[10000] = "";
				char partida[10000] = "";
				
				if (n_rows > 0) {
					row = mysql_fetch_row(resultado);
					sprintf(partida, "%s|%s|%s|%s|%s|%s", row[1], row[2], row[3], row[4], row[5], row[6]);
					while ((row = mysql_fetch_row(resultado))) {
						sprintf(partida, "%s*%s|%s|%s|%s|%s|%s", partida, row[1], row[2], row[3], row[4], row[5], row[6]);
					}
					sprintf(mensaje, "13/2/1/%s", partida);
					printf("Enviando mensaje: %s por el socket: '%d'\n", mensaje, sock_conn);
					int bytes_enviados = write(sock_conn, mensaje, strlen(mensaje));
					if (bytes_enviados <= 0) {
						printf("Error al enviar datos al cliente\n");
					}
					
				} else {
					printf("No se encontraron partidas con los jugadores especificados.\n");
					strcpy(buff, "13/2/-1");
					int bytes_enviados = write(sock_conn, buff, strlen(buff));
					if (bytes_enviados <= 0) {
						printf("Error al enviar datos al cliente\n");
					}
				}
				mysql_free_result(resultado);
			}
			
			
			else if(nConsulta == 3){ //Lista de partidas jugadas en un periodo de tiempo dado.
				
				char fechaInicio[200];
				char fechaFin[200];
				
				p = strtok(NULL, "|");
				if (p == NULL) {
					printf("Error: Fecha inicial no especificada.\n");					
					break;
				}
				strcpy(fechaInicio, p);
				
				p = strtok(NULL, "|");
				if (p == NULL) {
					printf("Error: Fecha final no especificada.\n");;
					break;
				}
				strcpy(fechaFin, p);
				
				char consulta2[1500];
				sprintf(consulta2, "SELECT * FROM Partida WHERE fecha BETWEEN '%s' AND '%s' AND (Jugador1 = '%s' OR Jugador2 = '%s' OR Jugador3 = '%s' OR Jugador4 = '%s');", fechaInicio, fechaFin, nomUsuario, nomUsuario, nomUsuario, nomUsuario);
				int err = mysql_query(conn, consulta2);
				if (err != 0) 
				{
					printf("Error al consultar datos de la base: %u %s\n", mysql_errno(conn), mysql_error(conn));
					close(sock_conn);
					pthread_exit(NULL);
				}
				
				resultado = mysql_store_result(conn);
				int n_rows = mysql_num_rows(resultado);
				char mensaje[10000] = "";
				char partida[10000] = "";
				
				if (n_rows > 0) {
					row = mysql_fetch_row(resultado);
					sprintf(partida, "%s|%s|%s|%s|%s|%s", row[1], row[2], row[3], row[4], row[5], row[6]);
					while ((row = mysql_fetch_row(resultado))) {
						sprintf(partida, "%s*%s|%s|%s|%s|%s|%s",partida, row[1], row[2], row[3], row[4], row[5], row[6]);						
					}	
					sprintf(mensaje, "13/3/1/%s", partida);
					printf("Enviando mensaje: %s por el socket: '%d'\n", mensaje, sock_conn);
					int bytes_enviados = write(sock_conn, mensaje, strlen(mensaje));
					if (bytes_enviados <= 0) {
						printf("Error al enviar datos al cliente\n");
					}
					
				} else {
					printf("No se encontraron partidas en el per�odo especificado.\n");
					strcpy(buff, "13/3/-1");
					int bytes_enviados = write(sock_conn, buff, strlen(buff));
					if (bytes_enviados <= 0) {
						printf("Error al enviar datos al cliente\n");
					}
				}
				mysql_free_result(resultado);
			}
		}
		else if(codigo == 20) // 
		{			
			p = strtok(NULL, "/");
			turno = atoi(p);
			
			char nombreAdmin[200];			
			p = strtok(NULL, "/");
			strcpy(nombreAdmin, p);			
			
			int roja1;
			roja1 = atoi(strtok(NULL, "/"));	
			int roja2;
			roja2 = atoi(strtok(NULL, "/"));	
			int roja3;
			roja3 = atoi(strtok(NULL, "/"));	
			int roja4;
			roja4 = atoi(strtok(NULL, "/"));
			
			int verde1;
			verde1 = atoi(strtok(NULL, "/"));	
			int verde2;
			verde2 = atoi(strtok(NULL, "/"));	
			int verde3;
			verde3 = atoi(strtok(NULL, "/"));	
			int verde4;
			verde4 = atoi(strtok(NULL, "/"));
			
			int azul1;
			azul1 = atoi(strtok(NULL, "/"));	
			int azul2;
			azul2 = atoi(strtok(NULL, "/"));	
			int azul3;
			azul3 = atoi(strtok(NULL, "/"));	
			int azul4;
			azul4 = atoi(strtok(NULL, "/"));
			
			int amarilla1;
			amarilla1 = atoi(strtok(NULL, "/"));	
			int amarilla2;
			amarilla2 = atoi(strtok(NULL, "/"));	
			int amarilla3;
			amarilla3 = atoi(strtok(NULL, "/"));	
			int amarilla4;
			amarilla4 = atoi(strtok(NULL, "/"));
			
			char jugadores[1500];
			char jugadores_2[1500];
			char notificacion[1500];
			VerSala(&listaInvit, nombreAdmin, jugadores);
			strcpy(jugadores_2, jugadores);
			
			char Sockets_Jugadores_Sala[400];
			int n = Dame_Sockets_Sala(&listaInvit, &listaConec, nombreAdmin, Sockets_Jugadores_Sala, jugadores_2); 	
			
			if(turno < n) turno += 1;
			else turno = 1;			
			sprintf(notificacion, "20/%d/%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d",turno, roja1, roja2, roja3, roja4, verde1, verde2, verde3, verde4, azul1, azul2, azul3, azul4, amarilla1, amarilla2, amarilla3, amarilla4);	
			
			printf("Sockets sala: %s\n", Sockets_Jugadores_Sala);
			printf("Jugadores sala: %s\n", jugadores);
			char *l = strtok(Sockets_Jugadores_Sala, "-");
			for (int i = 0; i < n; i++) {	
				if (l == NULL) break;
				int socket_actual = atoi(l);
				printf("Envio actualizaci�n de fichas y de turno a todos los jugadores de la partida: '%s' por el socket: '%d'\n", notificacion, socket_actual);
				int bytes_enviados = write(socket_actual, notificacion, strlen(notificacion));
				if (bytes_enviados <= 0) 
				{
					printf("Error al enviar datos al cliente\n");
				}
				l = strtok(NULL, "-");
			}
			printf("Actualizaci�n de fichas y de turno enviado a todos los usuarios de la sala!\n");
		}
		else if(codigo == 21) // Jugador abandona la partida
		{		
			char notificacion[200];
			char notificacion2[200];
			char jugadores[1500];
			char listaJugadores[1500];
			
			p = strtok(NULL, "/");
			strcpy(nomUsuario, p);
			
			int esAdmin = EsAdmin(&listaInvit, nomUsuario);
			if (esAdmin == 1) 
			{
				sprintf(notificacion2, "21/El administrador '%s' ha abandonado la partida.", nomUsuario);
				VerSala(&listaInvit, nomUsuario, jugadores);
				strcpy(listaJugadores, jugadores);
				char Sockets_Jugadores_Sala[400];
				int n = Dame_Sockets_Sala(&listaInvit, &listaConec, nomUsuario, Sockets_Jugadores_Sala, jugadores);
				
				if (n > 0) 
				{
					char *l = strtok(Sockets_Jugadores_Sala, "-");
					for (int i = 0; i < n; i++) 
					{
						if (l == NULL) break; // Verificar que l no sea NULL
						int socket_actual = atoi(l);
						printf("Envio notificaci�n de abandono de partida por el socket: '%d'\n", socket_actual);
						int bytes_enviados = write(socket_actual, notificacion2, strlen(notificacion2));
						if (bytes_enviados <= 0) {
							printf("Error al enviar datos al cliente\n");
						}
						l = strtok(NULL, "-");
					}
				}
				
				/*int eliminar = */ EliminarSala(&listaInvit, &listaConec, nomUsuario);
				sprintf(notificacion, "21/Has abandonado la partida.");
				
				int bytes_enviados = write(sock_conn, notificacion, strlen(notificacion));
				if (bytes_enviados <= 0) {
					printf("Error al enviar datos al cliente\n");
				}
			}
			else
			{
				int DentroSala = EstaEnSala(&listaConec, nomUsuario);
				if (DentroSala == 1)
				{
					char nombreSala[200];
					p = strtok(NULL, "/");
					strcpy(nombreSala, p);
					
					int abandonar = AbandonarSala(&listaInvit, &listaConec, nomUsuario, nombreSala);
					if (abandonar == 1) 
					{
						sprintf(notificacion, "21/Has abandonado la partida.");
						int bytes_enviados = write(sock_conn, notificacion, strlen(notificacion));
						if (bytes_enviados <= 0) {
							printf("Error al enviar datos al cliente\n");
						}
						
						char jugadores[1500];
						char jugadores_2[1500];
						char notificacion_jugadores[1500];
						VerSala(&listaInvit, nombreSala, jugadores);
						strcpy(jugadores_2, jugadores);
						char Sockets_Jugadores_Sala[400];
						int n = Dame_Sockets_Sala(&listaInvit, &listaConec, nombreSala, Sockets_Jugadores_Sala, jugadores_2);
						sprintf(notificacion_jugadores, "21/'%s' ha abandonado la partida.", nomUsuario);
						
						printf("Sockets partida: %s\n", Sockets_Jugadores_Sala);
						printf("Jugadores partida: %s\n", jugadores);
						
						char *l = strtok(Sockets_Jugadores_Sala, "-");
						for (int i = 0; i < n; i++) {
							if (l == NULL) break;
							int socket_actual = atoi(l);
							printf("Envio notificaci�n jugador ha abandonado: '%s' por el socket: '%d'\n", notificacion_jugadores, socket_actual);
							int bytes_enviados_jugadores = write(socket_actual, notificacion_jugadores, strlen(notificacion_jugadores));
							if (bytes_enviados_jugadores <= 0) {
								printf("Error al enviar datos al cliente\n");
							}
							l = strtok(NULL, "-");
						}
					}
				}
			}
		}
		else if (codigo == 22) //Se a�ade la partida a la tabla partidas
		{
			char fecha[20];
			p = strtok(NULL, "-");
			
			strncpy(fecha, p, sizeof(fecha) - 1);
			fecha[sizeof(fecha) - 1] = '\0';
			
			char admin[20];
			p = strtok(NULL, "-");
			strncpy(admin, p, sizeof(admin) - 1);
			admin[sizeof(admin) - 1] = '\0';
			
			char jugadores[200];
			int n = VerSala(&listaInvit, admin, jugadores);
			
			// Convertir n a cadena
			char n_str[4];
			snprintf(n_str, sizeof(n_str), "%d", n);
			
			// Insertar partida en la base de datos
			char consulta[1000];
			strcpy(consulta, "INSERT INTO Partida (fecha, N_Jugadores, Jugador1, Jugador2, Jugador3, Jugador4) VALUES ('");
			strcat(consulta, fecha);
			strcat(consulta, "', ");
			strcat(consulta, n_str);
			
			char *l = strtok(jugadores, "-");
			for (int i = 0; i < n; i++) 
			{
				strcat(consulta, ", '");
				strcat(consulta, l);
				strcat(consulta, "'");
				l = strtok(NULL, "-");
			}
			
			// Rellenar con NULL los jugadores faltantes
			for (int i = n; i < 4; i++) 
			{
				strcat(consulta, ", NULL");
			}
			
			strcat(consulta, ");");
			
			err = mysql_query(conn, consulta);
			if (err != 0) 
			{
				printf("Error al insertar datos en la base: %u %s\n", mysql_errno(conn), mysql_error(conn));
				close(sock_conn);
				pthread_exit(NULL);
			}
			
			printf("Partida guardada con exito!\n");
		}
		else if (codigo == 23)
		{			
			char *command = strtok(NULL, "/"); // obten el comando despues del codigo
			if (command == NULL)
			{
				printf("Error: Comando no especificado.\n");
				return 0;
			}
			
			if (strcmp(command, "BLOCK") == 0)
			{
				printf("Procesando comando BLOCK...\n");
				HandleBlockCommand(buff, conn, sock_conn);
			}
			else if (strcmp(command, "LOGIN") == 0)
			{
				printf("Procesando comando LOGIN...\n");
			}
			
			else
			{
				printf("Comando no reconocido: %s\n", command);
			}
		}
		
		else if (codigo == 30)
		{
			char *Nombre_Usuario = strtok(NULL, "/");
			if (Nombre_Usuario == NULL)
			{
				printf("Error: Nombre de usuario no especificado.\n");
				char response[] = "30/ERROR";
				write(sock_conn, response, strlen(response));
				return 0;
			}
			
			char query[512];
			snprintf(query, sizeof(query), "SELECT Nombre_Usuario, Victorias FROM Usuario WHERE Nombre_Usuario = '%s';", Nombre_Usuario);
			
			if (mysql_query(conn, query) != 0)
			{
				printf("Error al consultar la base de datos: %s\n", mysql_error(conn));
				char response[] = "30/ERROR";
				write(sock_conn, response, strlen(response));
				return 0;
			}
			
			MYSQL_RES *result = mysql_store_result(conn);
			if (result == NULL)
			{
				printf("Error al obtener resultados: %s\n", mysql_error(conn));
				char response[] = "30/ERROR";
				write(sock_conn, response, strlen(response));
				return 0;
			}
			MYSQL_ROW row = mysql_fetch_row(result);
			if (row != NULL)
			{
				char response[512];
				snprintf(response, sizeof(response), "30/OK/%s/%s", row[0], row[1]);
				write(sock_conn, response, strlen(response));
			}
			
			else
			{
				char response[] = "30/ERROR";
				write(sock_conn, response, strlen(response));
			}
			
			mysql_free_result(result);
		}
		
		else if (codigo == 34) // Comando para registrar resultados de una partida
		{
			char *idPartida = strtok(NULL, "/");
			char *ganador = strtok(NULL, "/");
			char *perdedor1 = strtok(NULL, "/");
			char *perdedor2 = strtok(NULL, "/");
			char *perdedor3 = strtok(NULL, "/");
			int fichasGanadas = atoi(strtok(NULL, "/"));
			
			// Actualizar estad�sticas del ganador
			char query[512];
			snprintf(query, sizeof(query), 
					 "UPDATE Usuario SET Victorias = Victorias + 1, Fichas_Comidas = Fichas_Comidas + %d WHERE Nombre_Usuario = '%s';", 
					 fichasGanadas, ganador);
			mysql_query(conn, query);
			
			// Actualizar estad�sticas de los perdedores
			snprintf(query, sizeof(query), 
					 "UPDATE Usuario SET Derrotas = Derrotas + 1 WHERE Nombre_Usuario = '%s' OR Nombre_Usuario = '%s' OR Nombre_Usuario = '%s';", 
					 perdedor1, perdedor2, perdedor3);
			mysql_query(conn, query);
			
			// Registrar participaci�n del ganador
			snprintf(query, sizeof(query), 
					 "INSERT INTO Participacion (IDJ, IDP, Resultado, Fichas_Comidas) VALUES ((SELECT ID_Usuario FROM Usuario WHERE Nombre_Usuario = '%s'), %s, 'Victoria', %d);", 
					 ganador, idPartida, fichasGanadas);
			mysql_query(conn, query);
			
			// Registrar participaci�n de los perdedores
			snprintf(query, sizeof(query), 
					 "INSERT INTO Participacion (IDJ, IDP, Resultado, Fichas_Comidas) VALUES ((SELECT ID_Usuario FROM Usuario WHERE Nombre_Usuario = '%s'), %s, 'Derrota', 0);", 
					 perdedor1, idPartida);
			mysql_query(conn, query);
			
			snprintf(query, sizeof(query), 
					 "INSERT INTO Participacion (IDJ, IDP, Resultado, Fichas_Comidas) VALUES ((SELECT ID_Usuario FROM Usuario WHERE Nombre_Usuario = '%s'), %s, 'Derrota', 0);", 
					 perdedor2, idPartida);
			mysql_query(conn, query);
			
			snprintf(query, sizeof(query), 
					 "INSERT INTO Participacion (IDJ, IDP, Resultado, Fichas_Comidas) VALUES ((SELECT ID_Usuario FROM Usuario WHERE Nombre_Usuario = '%s'), %s, 'Derrota', 0);", 
					 perdedor3, idPartida);
			mysql_query(conn, query);
			
			printf("Estad�sticas actualizadas para la partida %s.\n", idPartida);
		}
		
		else if (codigo == 35) // Comando para consultar estad�sticas del usuario
		{
			char *Nombre_Usuario = strtok(NULL, "/");
			
			// Consultar estad�sticas globales
			char query[512];
			snprintf(query, sizeof(query), 
					 "SELECT Victorias, Derrotas, Fichas_Comidas, Fecha_Registro FROM Usuario WHERE Nombre_Usuario = '%s';", 
					 Nombre_Usuario);
			
			if (mysql_query(conn, query) == 0)
			{
				MYSQL_RES *result = mysql_store_result(conn);
				MYSQL_ROW row = mysql_fetch_row(result);
				if (row)
				{
					char response[512];
					snprintf(response, sizeof(response), "35/OK/%s/%s/%s/%s", row[0], row[1], row[2], row[3]);
					write(sock_conn, response, strlen(response));
				}
				mysql_free_result(result);
			}
			else
			{
				char response[] = "35/ERROR";
				write(sock_conn, response, strlen(response));
			}
		}
		
		else if (codigo == 36)
		{
			char *Nombre_Usuario = strtok(NULL, "/");
			if (Nombre_Usuario == NULL)
			{
				printf("Error: Usuario no especificado.\n");
				return 0;
			}
			
			// Consulta SQL para obtener los datos del perfil del jugador
			char query[512];
			snprintf(query, sizeof(query), 
					 "SELECT fecha, N_Jugadores, Jugador1, Jugador2, Jugador3, Jugador4 "
					 "FROM Partida WHERE Jugador1 = '%s' OR Jugador2 = '%s' OR Jugador3 = '%s' OR Jugador4 = '%s';",
					 Nombre_Usuario, Nombre_Usuario, Nombre_Usuario, Nombre_Usuario);
			
			if (mysql_query(conn, query) == 0)
			{
				MYSQL_RES *result = mysql_store_result(conn);
				MYSQL_ROW row;
				char response[2000] = "36/";
				
				while ((row = mysql_fetch_row(result)) != NULL)
				{
					char partida[512];
					snprintf(partida, sizeof(partida), "%s|%s|%s|%s|%s|%s*", 
							 row[0], row[1], row[2], row[3], row[4], row[5]);
					strcat(response, partida);
				}
				
				mysql_free_result(result);
				write(sock_conn, response, strlen(response));
			}
			else
			{
				printf("Error al ejecutar la consulta: %s\n", mysql_error(conn));
				char response[] = "36/";
				write(sock_conn, response, strlen(response));
			}
		}
		
		else if (codigo == 37) // Consultar usuarios bloqueados por el usuario actual
		{
			char *username = strtok(NULL, "/");
			if (username == NULL)
			{
				printf("Error: Usuario no especificado.\n");
				return 0;
			}
			
			// Consulta para obtener usuarios bloqueados por el usuario actual
			char query[512];
			snprintf(query, sizeof(query), 
					 "SELECT Nombre_Usuario FROM Usuario WHERE Bloqueado = 1 AND Nombre_Usuario IN (SELECT Bloqueado_Usuario FROM Bloqueos WHERE Usuario = '%s');", username);
			
			if (mysql_query(conn, query) == 0)
			{
				MYSQL_RES *result = mysql_store_result(conn);
				MYSQL_ROW row;
				char response[1024] = "37/";
				
				while ((row = mysql_fetch_row(result)) != NULL)
				{
					strcat(response, row[0]);
					strcat(response, "|");
				}
				mysql_free_result(result);
				
				write(sock_conn, response, strlen(response));
			}
			else
			{
				printf("Error al consultar usuarios bloqueados: %s\n", mysql_error(conn));
				char response[] = "37/ERROR";
				write(sock_conn, response, strlen(response));
			}
		}
		
		else{
			printf("Codigo no valido.\n");
		}
	}	
	
	// Cerrar la conexion MySQL y el socket
	mysql_close(conn);
	close(sock_conn);
	pthread_exit(NULL);
}
int main(int argc, char *argv[]) {
	strcpy(ubi, "localhost");
	//strcpy(ubi, "shiva2.upc.es");
	//Inicio el MYSQL
	MYSQL *conn;
	/*int err;*/
	// Estructura necessaria para acesso excluyente
	pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
	
	// Estructura especial para almacenar resultados de consultas 
	MYSQL_RES *resultado;
	MYSQL_ROW row;
	//Creamos una conexion al servidor MYSQL 
	conn = mysql_init(NULL);
	if (conn == NULL) {
		printf("Error al crear la conexion: %u %s\n",
			   mysql_errno(conn), mysql_error(conn));
		exit(1);
	}
	//Inicializar la conexion
	// Conectar a la base de datos
	if ((conn=mysql_real_connect(conn, "localhost", "root", "mysql", "BBDD_PARCHIS", 3306, NULL, 0)) == NULL) {
		printf("Error al conectar a la base de datos: %s\n", mysql_error(conn));
		mysql_close(conn);
		exit(1);
		
	} else {
		printf("BD connection\n");
	}
	
	int sock_conn, sock_listen;/* , ret;*/
	struct sockaddr_in serv_adr;
	// INICIALITZACIONS
	// Obrim el socket
	if ((sock_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		printf("Error creando el socket\n");
	// Fem el bind al port
	memset(&serv_adr, 0, sizeof(serv_adr)); // inicialitza a zero serv_addr
	serv_adr.sin_family = AF_INET;
	// asocia el socket a cualquiera de las IP de la máquina. 
	// htonl formatea el numero que recibe al formato necesario
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	//50016
	serv_adr.sin_port = htons(9070);
	
	if (bind(sock_listen, (struct sockaddr *)&serv_adr, sizeof(serv_adr)) < 0)
		printf("Error al bind\n");
	//La cola de peticiones pendientes no podrá ser superior a 4
	if (listen(sock_listen, 2) < 0)
		printf("Error en el Listen\n");
	
	InicializarListas();
	
	int terminar = 0;
	
	pthread_t thread;
	
	while (terminar == 0) {
		printf("Escuchando\n");	
		
		sock_conn = accept(sock_listen, NULL, NULL);
		printf("He recibido conexion\n");
		//sock_conn es el socket que usaremos para este cliente
		
		sockets[i] = sock_conn;
		Conectado nuevaConex;
		
		//Crear hilo y decirle lo que tiene que hacer
		pthread_create(&thread, NULL, AtenderCliente, &sockets[i]);
		i++;
	}
	
	// Cerrar la conexion MySQL
	mysql_close(conn);
	
	return 0;
}

